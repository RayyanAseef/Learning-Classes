
package snake;

public class SnakeTail {
    
    public int x;
    public int y;
    
    public SnakeTail (int x, int y) {
        
        this.x = x;
        this.y = y;
        
    }
    
}
