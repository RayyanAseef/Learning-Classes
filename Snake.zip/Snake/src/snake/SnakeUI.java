package snake;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.BorderFactory;

import java.awt.GridLayout;
import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;

import java.util.*;

public class SnakeUI extends JFrame {
    
    private class Dispatch implements KeyEventDispatcher {
        
        @Override
        public boolean dispatchKeyEvent (KeyEvent e) {
            
            if (e.getID()!=KeyEvent.KEY_PRESSED) return false;
            Integer kc=e.getKeyCode();
            if (kc>40||kc<36) return false;
            sg.dir=kc-36;
            
            return true;
            
        }
        
    }
    
    private JPanel jp;
    private SnakeGame sg;
    
    public SnakeUI () {
        
        super();
        
        this.jp=new JPanel(); 
        this.jp.setBorder(BorderFactory.createEmptyBorder(600,600,0,0));
        this.jp.setLayout(new GridLayout(0,1));
        this.add(this.jp,BorderLayout.CENTER);
        this.setTitle("Snake");
        this.pack();
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(new Dispatch());
        
        this.sg = new SnakeGame(5); 
        
        new Timer ().schedule (new TimerTask() {
            
           @Override 
            public void run () {
                
                sg.calPosSnake();
                repaint();
                
            }
            
        },0,133);
        
    }
    
    @Override
    public void paint (Graphics graphics) {
        
        //Whenever the window paints itself
        //This code gets run
        
        super.paint(graphics);
        System.out.println("PAinted");
        
        graphics.setColor(Color.BLACK);
        graphics.fillRect(0,0,610,633);
        
        // 2 corner points are (-5,20)Top left and (610,633) Bottem Right
        graphics.setColor(Color.BLUE);
        graphics.fillRect(-5,20,30,613);
        graphics.fillRect(-5,20,620,30);
        graphics.fillRect(590,20,30,613);
        graphics.fillRect(-5,615,618,25);
        
        graphics.setColor(Color.GREEN);
        
        for (SnakeTail st: sg.tails) {
            
            graphics.fillRect(st.x,st.y,25,25);
            
        }
        
        graphics.setColor(Color.RED);
        graphics.fillRect(sg.apple.x,sg.apple.y,25,25);
        
    }
    
}