
package snake;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SnakeGame {
    
    public List<SnakeTail> tails; 
    public SnakeTail apple;
    
    public int size;
    
    public int dir = 1;//1==left 2==down 3==right 4==up
    
    Random rand;
    
    public void calPosSnake () {
        
        int i = tails.size() - 1;
        
        while (i!=0) {
            //i=4
            SnakeTail st = tails.get(i - 1);//i-1
            //Set i to the location of i-1
            tails.get(i).x = st.x;
            tails.get(i).y = st.y;
            --i;
            
        }
        
        switch (this.dir) {
            case 1:
                tails.get(0).x -= 30;
                break;
            case 2:
                tails.get(0).y -= 30;
                break;
            case 3:
                tails.get(0).x += 30;
                break;
            case 4:
                tails.get(0).y += 30;
                break;
        }
        
        int headX = tails.get(0).x;
        int headY = tails.get(0).y;
        i = 0;
        
        for (SnakeTail st: tails) {
            
            if (headX == st.x && headY == st.y) {
                ++i;
            }
            
        }
        
        if (i > 1) {
            System.exit(0);
        }
        
        if (headX == apple.x && headY == apple.y) {
            setPosApple();
            SnakeTail st0 = new SnakeTail(tails.get(tails.size() - 1).x + 30,tails.get(tails.size() - 1).y);
            tails.add(st0);
        }
        
        if (headX >= 595) {
            tails.get(0).x = 25;
        }
        
        else if (headY >= 600) {
            tails.get(0).y = 50;
        }
        
        else if (headX <= -5) {
            tails.get(0).x = 565;
        }
        
        else if (headY <= 20) {
            tails.get(0).y = 590;
        }
    }
    
    public void setPosApple() {
        
        int x = 0;
        int y = 0;
        
        for (int i = y;i == 0; i = y) {
            y = rand.nextInt(19);
        }
        
        for (int i = x;i == 0; i = x) {
            x = rand.nextInt(20);
        }
        
        x = (x * 30) - 5;
        y = (y * 30) + 20;
        
        this.apple = new SnakeTail(x,y);//x and y= (random number 0-15 * 30 )+20
        
        
        
    }
    
    public SnakeGame (int size) {
        
        rand = new Random();
        
        this.tails = new ArrayList<>();
        
        this.size = size;
        
        int i = 0;
        
        while (i != size) {
            
            SnakeTail st = new SnakeTail(205  + (i * 30),200);
            
            this.tails.add(st);
            
            ++i;
            
        }
        
        setPosApple();
    }
    
}
