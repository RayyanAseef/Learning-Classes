
package snake;

public class Snake {

    public static void main(String[] args) {
        
        SnakeUI ui = new SnakeUI();
        
    }
    
}
